function h=histdxdy(img,sigma,bins)

  % compute the first derivatives
  [imgDx,imgDy] = gaussderiv(img,sigma);
  
  %quantize the images to "bins" number of values
  imgDx = imgDx + 80;
  imgDy = imgDy + 80;
  imgDx( find(imgDx < 0) )   = 0;
  imgDx( find(imgDx > 159) ) = 159;
  imgDy( find(imgDy < 0) )   = 0;
  imgDy( find(imgDy > 159) ) = 159;
  imgDx = floor(imgDx*(bins/160))+1;
  imgDy = floor(imgDy*(bins/160))+1;
  
  %define a 2D histogram  with "bins^2" number of entries
  h=zeros(bins,bins);

  %execute the loop for each pixel in the image, 
  for i=1:size(img,1)
    for j=1:size(img,2)

      %increment a histogram bin which corresponds to the value 
      %of pixel i,j; 
      dx = imgDx(i,j);
      dy = imgDy(i,j);
      
      h(dx,dy) = h(dx,dy)+1;
    end
  end

  %normalize the histogram such that its integral (sum) is equal 1
  h=h/sum(sum(h));
  h=reshape(h,bins^2,1);
end
