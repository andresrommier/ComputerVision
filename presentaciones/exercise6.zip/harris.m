function [px py] = harris( img, sigma, thresh )
  
[imgDx imgDy] = gaussderiv(img, sigma);
imgDx2 = gaussianfilter(sigma^2*imgDx.^2, 1.6*sigma);
imgDy2 = gaussianfilter(sigma^2*imgDy.^2, 1.6*sigma);
imgDxy = gaussianfilter(sigma^2*imgDx .* imgDy, 1.6*sigma);

imgDet   = imgDx2.*imgDy2 - imgDxy.^2;
imgTrace = imgDx2 + imgDy2;

imgPts = imgDet - 0.06*imgTrace.^2;
imgPts = nonmaxsup2d( imgPts );

[py px] = find(imgPts > thresh);
  
end