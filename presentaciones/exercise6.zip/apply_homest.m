% load two example images
img1 = double(imread('NewYork/im1.pgm'));
img2 = double(imread('NewYork/im5.pgm'));

% compute Harris interest points
[px1 py1] = harris(img1, 1.0, 1000);
[px2 py2] = harris(img2, 1.0, 1000);

% compute the dx/dy descriptors
D1 = descriptors_maglap(img1, px1, py1, 41, 2.0, 16 );
D2 = descriptors_maglap(img2, px2, py2, 41, 2.0, 16 );

% find the best matches and sort them according to their scores
[Idx Dist] = findnn_chi2(D1,D2);

%displaymatches( img1, px1, py1, img2, px2, py2, Idx, Dist, 10 );
[SDist SIdx] = sort(Dist,'ascend');
k = 5;
x1 = px1(SIdx(1:k));
y1 = py1(SIdx(1:k));
x2 = px2(SIdx(1:k));
y2 = py2(SIdx(1:k));
H = estimate_homography(x1, y1, x2, y2);
H
h = hom_gui_H(uint8(img1),uint8(img2),H);
