function [Idx, Dist] = findnn(D1, D2)

  for i=1:size(D1)
    for j=1:size(D2)
      dists(i,j) = norm(D1(i,:) - D2(j,:), 2); 
    end
  end

  for i=1:size(D1)
    [Dist(i), Idx(i)] = min(dists(i,:));
  end

end
