function imgLap=laplace(img,sigma)
% Loesung Gregor Mitsch

[imgDxx, imgDxy, imgDyy ] = gaussderiv2(img, sigma);

imgLap = imgDxx + imgDyy;

end