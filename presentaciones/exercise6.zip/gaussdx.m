function D=gaussdx(x,sigma)

D = -2*(x.*exp(-x.^2/(2*sigma^2)))/(sqrt(2*pi)*sigma^3);
%D = x.*exp(-x.^2/(2*sigma^2));
%D=D/sum(sum(D));

end
