
% load an image
%img = double(rgb2gray(imread('graf.png')));
img = double(rgb2gray(imread('gantrycrane.png')));

% apply the harris detector
[px py] = harris(img, 1.0, 1000);
drawpoints(img, px, py, 'y');
