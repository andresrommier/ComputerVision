function [px py]=hessian(img, sigma, thresh)


[imgDxx,imgDxy,imgDyy] = gaussderiv2(img,sigma);

imgHesdet = sigma^4 * (imgDxx.*imgDyy-imgDxy.^2);
%figure; colormap gray; imagesc(imgHesdet);

imgPts = nonmaxsup2d( imgHesdet );
%figure; colormap gray; imagesc(imgPts);

[py px] = find(imgPts > thresh);
